# Cartalith project

This archive is a Cartalith project, not a plain image export.
`project.json` says which format version it is.

    project.json      what this file is, and the grid every raster is measured against
    params.json       the settings the world was generated from
    rasters/          one value per grid cell -- elevation, climate, hydrology, territory
    entities/         settlements, factions, roads, provinces, continents
    history/          recorded past years
    annotations/      labels, icons and the selected region -- marks on the map
    library/          setting-level definitions that outlive any one world
    drafts/           uncommitted edits
    cartography/      optional cached zoom tiles -- derived from rasters/,
                      often absent, and safe to delete
    appearance.json   how the map is drawn
    vault.json        links out to an external Markdown vault
    preview.png       a thumbnail; not map data

Every raster decodes to a bare little-endian binary dump with no header:
exactly grid_width * grid_height elements, row-major,
index = y * grid_width + x. A `*.u8` entry is that dump as stored. A
`*.shuffled.f32` / `*.shuffled.i32` entry is byte-plane shuffled: all of the
elements' first bytes, then all their second bytes, then third, then fourth.
Byte k of element i is at offset k * (grid_width * grid_height) + i.
